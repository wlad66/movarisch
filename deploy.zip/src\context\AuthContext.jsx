import React, { createContext, useState, useContext, useEffect } from 'react';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
    const [user, setUser] = useState(null);
    const [company, setCompany] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        // Simula il controllo della sessione al caricamento
        const storedUser = localStorage.getItem('movarisch_user');
        const storedCompany = localStorage.getItem('movarisch_company');

        if (storedUser && storedCompany) {
            setUser(JSON.parse(storedUser));
            setCompany(JSON.parse(storedCompany));
        }
        setLoading(false);
    }, []);

    const login = (email, password) => {
        // Simula login - In futuro chiamata API
        // Per demo: accetta qualsiasi cosa se c'è nel localStorage, altrimenti errore
        // MA per semplificare la demo ora: cerchiamo nel localStorage "registered_users"

        const users = JSON.parse(localStorage.getItem('movarisch_db_users') || '[]');
        const foundUser = users.find(u => u.email === email && u.password === password);

        if (foundUser) {
            setUser(foundUser);
            setCompany(foundUser.company); // Assumiamo struttura { ...user, company: { ... } }

            localStorage.setItem('movarisch_user', JSON.stringify(foundUser));
            localStorage.setItem('movarisch_company', JSON.stringify(foundUser.company));
            return true;
        }
        return false;
    };

    const register = (userData, companyData) => {
        // Crea nuovo utente con azienda
        const newUser = {
            id: Date.now(),
            ...userData,
            company: {
                id: Date.now(),
                ...companyData
            }
        };

        // Salva nel "DB" locale
        const users = JSON.parse(localStorage.getItem('movarisch_db_users') || '[]');
        users.push(newUser);
        localStorage.setItem('movarisch_db_users', JSON.stringify(users));

        // Auto-login
        setUser(newUser);
        setCompany(newUser.company);
        localStorage.setItem('movarisch_user', JSON.stringify(newUser));
        localStorage.setItem('movarisch_company', JSON.stringify(newUser.company));

        return true;
    };

    const logout = () => {
        setUser(null);
        setCompany(null);
        localStorage.removeItem('movarisch_user');
        localStorage.removeItem('movarisch_company');
    };

    return (
        <AuthContext.Provider value={{ user, company, login, register, logout, loading }}>
            {children}
        </AuthContext.Provider>
    );
};

export const useAuth = () => useContext(AuthContext);
