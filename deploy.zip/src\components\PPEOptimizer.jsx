import React, { useState, useMemo } from 'react';
import { Shield, AlertTriangle, CheckCircle, XCircle, Info } from 'lucide-react';
import ppeData from '../data/ppe_database.json';

const PPEOptimizer = ({ savedAssessments = [], onArchive }) => {
    // Helper function to normalize CAS numbers (remove leading zeros)
    const normalizeCAS = (cas) => {
        if (!cas) return '';
        return cas.split('-').map(part => parseInt(part, 10).toString()).join('-');
    };

    const [selectedChemicals, setSelectedChemicals] = useState([]);
    const [selectedGloves, setSelectedGloves] = useState([]);

    // Toggle glove selection
    const toggleGlove = (gloveId) => {
        if (selectedGloves.includes(gloveId)) {
            setSelectedGloves(selectedGloves.filter(id => id !== gloveId));
        } else {
            setSelectedGloves([...selectedGloves, gloveId]);
        }
    };

    const handleArchive = () => {
        if (selectedGloves.length === 0) {
            alert("Seleziona almeno un guanto da archiviare.");
            return;
        }

        const report = {
            chemicals: selectedChemicals.map(cas => {
                const chem = ppeData.chemicals.find(c => c.cas === cas);
                return { cas, name: chem ? chem.name : cas };
            }),
            gloves: selectedGloves.map(gloveId => {
                const glove = ppeData.gloves.find(g => g.id === gloveId);
                return glove;
            })
        };

        onArchive(report);
    };

    // Sync saved assessments with selected chemicals on load
    // Show ONLY user-added chemicals (savedAssessments), not the entire database
    const availableChemicals = useMemo(() => {
        return savedAssessments; // Only show user-added chemicals
    }, [savedAssessments]);

    // Helper to get chemical name
    const getChemicalName = (cas) => {
        const chem = availableChemicals.find(c => c.cas === cas);
        return chem ? chem.name : cas;
    };

    // Sync saved assessments with selected chemicals on load
    React.useEffect(() => {
        if (savedAssessments.length > 0) {
            const newCas = savedAssessments.map(a => a.cas);

            setSelectedChemicals(prev => {
                const unique = new Set([...prev, ...newCas]);
                return Array.from(unique);
            });
        }
    }, [savedAssessments]);

    // Toggle chemical selection
    const toggleChemical = (cas) => {
        if (selectedChemicals.includes(cas)) {
            setSelectedChemicals(selectedChemicals.filter(c => c !== cas));
        } else {
            setSelectedChemicals([...selectedChemicals, cas]);
        }
    };

    // Optimization Logic
    const analysis = useMemo(() => {
        if (selectedChemicals.length === 0) return null;

        const gloveScores = ppeData.gloves.map(glove => {
            let minScore = 3; // Start with max score (Green)
            let details = [];

            selectedChemicals.forEach(cas => {
                // Normalize the CAS number for matching
                const normalizedCas = normalizeCAS(cas);

                // Get the chemical from availableChemicals to check its percentage
                const chemical = availableChemicals.find(c => normalizeCAS(c.cas) === normalizedCas);
                const chemPercentage = chemical?.percentage || 100;

                // Try exact match first (normalized CAS + percentage)
                let perf = ppeData.performance.find(p =>
                    normalizeCAS(p.cas) === normalizedCas &&
                    p.percentage === chemPercentage &&
                    p.gloveId === glove.id
                );

                // If no exact match, find best match (highest percentage for this CAS)
                if (!perf) {
                    const allPerfsForCas = ppeData.performance.filter(p =>
                        normalizeCAS(p.cas) === normalizedCas && p.gloveId === glove.id
                    );
                    if (allPerfsForCas.length > 0) {
                        // Sort by percentage descending and take the first (highest)
                        perf = allPerfsForCas.sort((a, b) => b.percentage - a.percentage)[0];
                    }
                }

                const color = perf ? perf.color : 'gray';
                let score = 0;
                if (color === 'green') score = 3;
                if (color === 'yellow') score = 2;
                if (color === 'orange') score = 1;
                if (color === 'red') score = 0;

                if (score < minScore) minScore = score;

                details.push({
                    cas,
                    time: perf ? perf.time : 'N/A',
                    color,
                    score
                });
            });

            return {
                ...glove,
                minScore,
                details
            };
        });

        // Sort by safety (best minimum score first)
        gloveScores.sort((a, b) => b.minScore - a.minScore);

        return gloveScores;
    }, [selectedChemicals]);

    const getTrafficLight = (color) => {
        const map = {
            green: "bg-green-500",
            yellow: "bg-yellow-400",
            orange: "bg-orange-500",
            red: "bg-red-600",
            gray: "bg-slate-300"
        };
        return map[color] || "bg-slate-300";
    };

    return (
        <div className="p-6 max-w-6xl mx-auto">
            <div className="mb-8">
                <h2 className="text-2xl font-bold text-slate-800 flex items-center gap-2">
                    <Shield className="text-blue-600" />
                    Ottimizzatore DPI Multi-Prodotto
                </h2>
                <p className="text-slate-600">Seleziona i prodotti chimici presenti in reparto per trovare il guanto compatibile.</p>
            </div>

            <div className="grid md:grid-cols-3 gap-8">
                {/* Selection Panel */}
                <div className="bg-white p-4 rounded-xl shadow border border-slate-200">
                    <h3 className="font-bold text-slate-700 mb-4">1. Inventario Chimico</h3>

                    <div className="space-y-2 max-h-[500px] overflow-y-auto">
                        {availableChemicals.map(chem => (
                            <div
                                key={chem.cas}
                                onClick={() => toggleChemical(chem.cas)}
                                className={`p-3 rounded-lg border cursor-pointer transition flex justify-between items-center ${selectedChemicals.includes(chem.cas) ? 'bg-blue-50 border-blue-500 ring-1 ring-blue-500' : 'hover:bg-slate-50 border-slate-200'}`}
                            >
                                <div>
                                    <div className="font-bold text-sm text-slate-800">{chem.name}</div>
                                    <div className="text-xs text-slate-500 font-mono">CAS: {chem.cas}</div>
                                    {savedAssessments.find(a => a.cas === chem.cas) && (
                                        <span className="text-[10px] bg-blue-100 text-blue-700 px-1.5 py-0.5 rounded mt-1 inline-block">Inserito da Utente</span>
                                    )}
                                </div>
                                {selectedChemicals.includes(chem.cas) && <CheckCircle size={16} className="text-blue-600" />}
                            </div>
                        ))}
                    </div>
                </div>

                {/* Results Panel */}
                <div className="md:col-span-2 space-y-6">
                    {selectedChemicals.length === 0 ? (
                        <div className="h-full flex flex-col items-center justify-center text-slate-400 border-2 border-dashed border-slate-200 rounded-xl p-8">
                            <Info size={48} className="mb-4 opacity-50" />
                            <p>Seleziona almeno un prodotto per iniziare l'analisi.</p>
                        </div>
                    ) : (
                        <>
                            {/* Best Recommendation */}
                            {analysis[0].minScore >= 2 ? (
                                <div className="bg-green-50 border border-green-200 p-4 rounded-xl flex items-start gap-4">
                                    <div className="bg-green-100 p-2 rounded-full">
                                        <CheckCircle className="text-green-600" size={24} />
                                    </div>
                                    <div>
                                        <h3 className="font-bold text-green-900 text-lg">
                                            DPI Consigliato: {analysis[0].material === 'N/A' || analysis[0].thickness === 'N/A'
                                                ? `Guanto: ${analysis[0].name}`
                                                : `Guanto in ${analysis[0].material} (${analysis[0].thickness})`
                                            }
                                        </h3>
                                        <p className="text-green-800 text-sm mt-1">
                                            {analysis[0].material !== 'N/A' && analysis[0].thickness !== 'N/A' && (
                                                <><span className="font-medium">Esempio:</span> {analysis[0].name} <span className="italic opacity-80">(o equivalente)</span></>
                                            )}
                                        </p>
                                        <p className="text-green-800 text-xs mt-1 opacity-80">
                                            Offre una protezione adeguata per TUTTI i prodotti selezionati.
                                        </p>
                                    </div>
                                </div>
                            ) : (
                                <div className="bg-red-50 border border-red-200 p-4 rounded-xl flex items-start gap-4">
                                    <div className="bg-red-100 p-2 rounded-full">
                                        <AlertTriangle className="text-red-600" size={24} />
                                    </div>
                                    <div>
                                        <h3 className="font-bold text-red-900 text-lg">Nessun DPI Unico Trovato</h3>
                                        <p className="text-red-800 text-sm mt-1">
                                            Attenzione: Nessun guanto singolo protegge adeguatamente da tutti i prodotti selezionati. È necessario differenziare i DPI o segregare le lavorazioni.
                                        </p>
                                    </div>
                                </div>
                            )}

                            {/* Matrix Table */}
                            <div className="bg-white rounded-xl shadow overflow-hidden border border-slate-200">
                                <table className="w-full text-sm text-left">
                                    <thead className="bg-slate-50 text-slate-600 font-medium border-b">
                                        <tr>
                                            <th className="p-3 w-10">Sel.</th>
                                            <th className="p-3">Guanto / Materiale</th>
                                            {selectedChemicals.map(cas => {
                                                const name = getChemicalName(cas);
                                                return <th key={cas} className="p-3 w-32 truncate" title={name}>{name}</th>
                                            })}
                                        </tr>
                                    </thead>
                                    <tbody className="divide-y divide-slate-100">
                                        {analysis.map(glove => (
                                            <tr key={glove.id} className={`hover:bg-slate-50 ${selectedGloves.includes(glove.id) ? 'bg-blue-50' : ''}`}>
                                                <td className="p-3 text-center">
                                                    <input
                                                        type="checkbox"
                                                        checked={selectedGloves.includes(glove.id)}
                                                        onChange={() => toggleGlove(glove.id)}
                                                        className="w-4 h-4 text-blue-600 rounded focus:ring-blue-500"
                                                    />
                                                </td>
                                                <td className="p-3">
                                                    {glove.material === 'N/A' || glove.thickness === 'N/A' ? (
                                                        <div className="font-bold text-slate-800">{glove.name}</div>
                                                    ) : (
                                                        <>
                                                            <div className="font-bold text-slate-800">{glove.material} • {glove.thickness}</div>
                                                            <div className="text-xs text-slate-500">Tipo: {glove.name}</div>
                                                        </>
                                                    )}
                                                </td>
                                                {glove.details.map(d => (
                                                    <td key={d.cas} className="p-3">
                                                        <div className="flex items-center gap-2">
                                                            <div className={`w-3 h-3 rounded-full ${getTrafficLight(d.color)}`}></div>
                                                            <span className="font-mono text-xs">{d.time}'</span>
                                                        </div>
                                                    </td>
                                                ))}
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>

                            <div className="flex justify-end mt-4">
                                <button
                                    onClick={handleArchive}
                                    className="flex items-center gap-2 px-6 py-3 bg-blue-900 text-white rounded-lg font-bold hover:bg-blue-800 shadow-lg transition"
                                >
                                    <Shield size={20} />
                                    Archivia Selezione DPI
                                </button>
                            </div>
                        </>
                    )}
                </div>
            </div>
        </div>
    );
};

export default PPEOptimizer;
