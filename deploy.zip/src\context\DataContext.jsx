import React, { createContext, useState, useContext, useEffect } from 'react';
import { useAuth } from './AuthContext';

const DataContext = createContext(null);

export const DataProvider = ({ children }) => {
    const { user } = useAuth();
    const [workplaces, setWorkplaces] = useState([]);
    const [roles, setRoles] = useState([]); // Mansioni
    const [inventory, setInventory] = useState([]); // Agenti Chimici
    const [loading, setLoading] = useState(true);

    // Carica dati al login
    useEffect(() => {
        if (user) {
            const storedWorkplaces = JSON.parse(localStorage.getItem(`movarisch_workplaces_${user.company.id}`) || '[]');
            const storedRoles = JSON.parse(localStorage.getItem(`movarisch_roles_${user.company.id}`) || '[]');
            const storedInventory = JSON.parse(localStorage.getItem(`movarisch_inventory_${user.company.id}`) || '[]');

            setWorkplaces(storedWorkplaces);
            setRoles(storedRoles);
            setInventory(storedInventory);
        } else {
            setWorkplaces([]);
            setRoles([]);
            setInventory([]);
        }
        setLoading(false);
    }, [user]);

    // --- WORKPLACES ---
    const addWorkplace = (name) => {
        const newWorkplace = { id: Date.now(), name };
        const updated = [...workplaces, newWorkplace];
        setWorkplaces(updated);
        localStorage.setItem(`movarisch_workplaces_${user.company.id}`, JSON.stringify(updated));
    };

    const deleteWorkplace = (id) => {
        const updated = workplaces.filter(w => w.id !== id);
        setWorkplaces(updated);
        localStorage.setItem(`movarisch_workplaces_${user.company.id}`, JSON.stringify(updated));
    };

    // --- ROLES (Mansioni) ---
    const addRole = (name, description) => {
        const newRole = { id: Date.now(), name, description };
        const updated = [...roles, newRole];
        setRoles(updated);
        localStorage.setItem(`movarisch_roles_${user.company.id}`, JSON.stringify(updated));
    };

    const deleteRole = (id) => {
        const updated = roles.filter(r => r.id !== id);
        setRoles(updated);
        localStorage.setItem(`movarisch_roles_${user.company.id}`, JSON.stringify(updated));
    };

    // --- INVENTORY (Agenti) ---
    const addToInventory = (agent) => {
        // agent: { name, cas, hCodes, ... }
        const newAgent = { id: Date.now(), ...agent };
        const updated = [...inventory, newAgent];
        setInventory(updated);
        localStorage.setItem(`movarisch_inventory_${user.company.id}`, JSON.stringify(updated));
    };

    const deleteFromInventory = (id) => {
        const updated = inventory.filter(i => i.id !== id);
        setInventory(updated);
        localStorage.setItem(`movarisch_inventory_${user.company.id}`, JSON.stringify(updated));
    };

    return (
        <DataContext.Provider value={{
            workplaces, addWorkplace, deleteWorkplace,
            roles, addRole, deleteRole,
            inventory, addToInventory, deleteFromInventory,
            loading
        }}>
            {children}
        </DataContext.Provider>
    );
};

export const useData = () => useContext(DataContext);
